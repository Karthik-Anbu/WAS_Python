#!/bin/bash
PROP_FILE=$1
source $PROP_FILE

$IMCL_PATH install com.ibm.websphere.ND.v90 -repositories $EXPORT_REPO -installationDirectory $WAS9_ROOT -acceptLicense

$WAS9_ROOT/bin/manageprofiles.sh -create -profileName $WAS9_PROFILE -profilePath $WAS9_PROFILE_PATH -templatePath $WAS9_ROOT/profileTemplates/management

cp -r $EXPORT_REPO/profile_backup/* $WAS9_PROFILE_PATH/

echo "Import complete to $WAS9_PROFILE_PATH"

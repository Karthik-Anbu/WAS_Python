#!/bin/bash
PROP_FILE=$1
source $PROP_FILE

mkdir -p $EXPORT_REPO

$IMCL_PATH export $WAS8_ROOT $EXPORT_REPO/repository.config -repositories $EXPORT_REPO

cp -r $WAS8_PROFILE_PATH $EXPORT_REPO/profile_backup

echo "Export complete: $EXPORT_REPO"
